#!/usr/bin/env -P /usr/bin:/usr/local/bin python3 -B
# coding: utf-8

#
#  GetImages.py
#  GetImages version 1.0
#  Created by Ingenuity i/o on 2023/11/21
#
# "no description"
#
import ingescape as igs


class Singleton(type):
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]


class GetImages(metaclass=Singleton):
    def __init__(self):
        # inputs
        self.departI = None
        self.arriveeI = None



