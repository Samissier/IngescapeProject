from enum import Enum

class EVille(Enum):
    Paris = "Paris"
    Toulouse = "Toulouse"
    Bordeaux = "Bordeaux"
    Lyon = "Lyon"